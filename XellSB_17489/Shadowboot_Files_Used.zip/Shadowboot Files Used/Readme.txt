Built using the latest version of Xell bundled with the JRunner app.
These shadowboot files can be loaded using any of the standard methods.
Simply rename the chosen file xboxromw2d.bin and place on Hdd. 
Be sure to have a method of removing from Hdd without a booting console!

xboxromw2d-Xell.bin - Real Devkit consoles

xboxromw2d-Xell_NOSIG.bin - JTAG/RGH running Dev kernel with SB sig patches applied (XDKBuild / Newer RGLoader Github Builds)


- Byrom -